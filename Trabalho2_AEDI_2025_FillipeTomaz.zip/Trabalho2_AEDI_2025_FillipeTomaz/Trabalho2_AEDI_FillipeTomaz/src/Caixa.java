public class Caixa {
    int guiche;
    boolean preferencial;
    Atendente atendente;

    public int getGuiche() {
        return guiche;
    }

    
    
}
